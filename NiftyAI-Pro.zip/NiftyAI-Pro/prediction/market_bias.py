"""
Sprint 9 - Package 1
Market Bias Engine
"""

from dataclasses import dataclass


@dataclass
class MarketBiasResult:
    bias: str
    score: float
    reason: str


class MarketBiasEngine:

    def evaluate(
        self,
        bullish_rate,
        bearish_rate,
        confidence,
        avg5,
        avg10
    ):

        score = 50

        if bullish_rate > bearish_rate:
            score += (bullish_rate - bearish_rate) * 0.30
        else:
            score -= (bearish_rate - bullish_rate) * 0.30

        score += avg5 * 5
        score += avg10 * 2

        score += (confidence - 50) * 0.20

        score = max(0, min(100, score))

        if score >= 65:
            bias = "BULLISH"

        elif score <= 35:
            bias = "BEARISH"

        else:
            bias = "SIDEWAYS"

        if bias == "BULLISH":
            reason = "Historical statistics favour upside continuation."

        elif bias == "BEARISH":
            reason = "Historical statistics favour downside continuation."

        else:
            reason = "Historical data does not indicate a clear directional edge."

        return MarketBiasResult(
            bias=bias,
            score=round(score, 2),
            reason=reason
        )