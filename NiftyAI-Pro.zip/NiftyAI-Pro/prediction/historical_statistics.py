"""
Sprint 14
Historical Statistics Engine

Removes all hard-coded values from the backtest engine.
"""

from dataclasses import dataclass

import pandas as pd


@dataclass
class HistoricalStatisticsResult:

    bullish_rate: float

    bearish_rate: float

    confidence: float

    avg5: float

    avg10: float

    similar_df: pd.DataFrame


class HistoricalStatisticsEngine:

    def __init__(self):

        pass

    # ---------------------------------------------------------

    def calculate(

        self,

        feature_df,

        indicator_df,

        lookback_df

    ):

        df = lookback_df.copy()

        if df.empty:

            return HistoricalStatisticsResult(

                bullish_rate=50,

                bearish_rate=50,

                confidence=50,

                avg5=0,

                avg10=0,

                similar_df=pd.DataFrame()

            )

        # -----------------------------------------------------
        # Bullish / Bearish probability
        # -----------------------------------------------------

        bullish = len(

            df[df["daily_return"] > 0]

        )

        bearish = len(

            df[df["daily_return"] <= 0]

        )

        total = bullish + bearish

        if total == 0:

            bullish_rate = 50

            bearish_rate = 50

        else:

            bullish_rate = round(

                bullish * 100 / total,

                2

            )

            bearish_rate = round(

                bearish * 100 / total,

                2

            )

        # -----------------------------------------------------
        # Average Returns
        # -----------------------------------------------------

        avg5 = round(

            df["return_5d"].fillna(0).mean(),

            2

        )

        avg10 = round(

            df["return_10d"].fillna(0).mean(),

            2

        )

        # -----------------------------------------------------
        # Confidence
        # -----------------------------------------------------

        confidence = round(

            max(

                bullish_rate,

                bearish_rate

            ),

            2

        )

        # -----------------------------------------------------
        # Similar historical sample
        # -----------------------------------------------------

        similar_df = df[

            [

                "return_5d",

                "return_10d"

            ]

        ].fillna(0)

        return HistoricalStatisticsResult(

            bullish_rate=bullish_rate,

            bearish_rate=bearish_rate,

            confidence=confidence,

            avg5=avg5,

            avg10=avg10,

            similar_df=similar_df

        )


# ---------------------------------------------------------

if __name__ == "__main__":

    print("Historical Statistics Engine Ready")