import pandas as pd

from sqlalchemy import create_engine

from sklearn.preprocessing import StandardScaler

from config.settings import DATABASE_URL

from sklearn.neighbors import NearestNeighbors

# -------------------------------------------------------
# Database Connection
# -------------------------------------------------------

engine = create_engine(DATABASE_URL)


# -------------------------------------------------------
# Load Historical Dataset
# -------------------------------------------------------

query = """
SELECT

c.candle_time,
c.close,

i.ema20,
i.ema50,
i.ema200,
i.rsi14,
i.macd,
i.macd_signal,
i.atr14,

f.gap_percent,
f.daily_return,
f.ema20_distance,
f.ema50_distance,
f.ema200_distance,
f.above_ema20,
f.above_ema50,
f.above_ema200,
f.bullish_macd,
f.rsi_zone,
f.return_5d,
f.return_10d

FROM candle c

JOIN indicator i
ON c.id=i.candle_id

JOIN feature_store f
ON c.id=f.candle_id

ORDER BY c.candle_time
"""

df = pd.read_sql(query, engine)

print("=" * 70)
print("HISTORICAL SIMILARITY ENGINE V2")
print("=" * 70)

print(f"\nTotal Records Loaded : {len(df)}")


# -------------------------------------------------------
# Encode Boolean Columns
# -------------------------------------------------------

bool_columns = [
    "above_ema20",
    "above_ema50",
    "above_ema200",
    "bullish_macd"
]

for col in bool_columns:
    df[col] = df[col].astype(int)


# -------------------------------------------------------
# Encode RSI Zone
# -------------------------------------------------------

mapping = {
    "Bearish": 0,
    "Neutral": 1,
    "Bullish": 2
}

df["rsi_zone"] = df["rsi_zone"].map(mapping)


# -------------------------------------------------------
# Features used for Similarity
# -------------------------------------------------------

FEATURE_COLUMNS = [

"gap_percent",

"daily_return",

"ema20_distance",

"ema50_distance",

"ema200_distance",

"above_ema20",

"above_ema50",

"above_ema200",

"bullish_macd",

"rsi_zone"

]


# -------------------------------------------------------
# Remove incomplete rows
# -------------------------------------------------------

df = df.dropna(subset=FEATURE_COLUMNS)

print(f"Records After Cleaning : {len(df)}")


# -------------------------------------------------------
# Build Feature Matrix
# -------------------------------------------------------

X = df[FEATURE_COLUMNS].copy()

print(f"Feature Matrix Shape : {X.shape}")


# -------------------------------------------------------
# Standardize Features
# -------------------------------------------------------

scaler = StandardScaler()

# -------------------------------------------------------
# Feature Scaling
# -------------------------------------------------------

scaler = StandardScaler()

X_scaled = scaler.fit_transform(X)

# -------------------------------------------------------
# AI Feature Weighting
# -------------------------------------------------------

feature_weights = {

    "gap_percent":0.75,

    "daily_return":1.00,

    "ema20_distance":2.50,

    "ema50_distance":2.50,

    "ema200_distance":3.00,

    "above_ema20":1.50,

    "above_ema50":1.50,

    "above_ema200":2.50,

    "bullish_macd":2.00,

    "rsi_zone":2.50

}

for i,column in enumerate(FEATURE_COLUMNS):

    X_scaled[:,i] *= feature_weights[column]

print("\nFeature Weighting Applied Successfully")

print("Scaling Completed")


# -------------------------------------------------------
# Current Market
# -------------------------------------------------------

current = df.iloc[-1]

print("\nCurrent Analysis Date :", current["candle_time"].date())

print("\nCurrent Feature Vector\n")

print(current[FEATURE_COLUMNS])

print("\nPackage 1 Completed Successfully.")

# -------------------------------------------------------
# Package 2 - KNN Similarity Search
# -------------------------------------------------------

print("\n" + "=" * 70)
print("PACKAGE 2 - KNN SIMILARITY SEARCH")
print("=" * 70)

# Exclude the most recent 30 trading sessions
historical_df = df.iloc[:-30].copy()

historical_X = X_scaled[:-30]

# Current day's feature vector
current_vector = X_scaled[-1].reshape(1, -1)

# Build KNN model
knn = NearestNeighbors(
    n_neighbors=10,
    metric="minkowski",
p=2
)

knn.fit(historical_X)

# Search nearest neighbours
# Search nearest neighbours
distances, indices = knn.kneighbors(current_vector)

print("\nTop 10 Similar Historical Days\n")

similar_days = []

# Calculate once
min_distance = distances[0].min()
max_distance = distances[0].max()

for rank, (distance, idx) in enumerate(zip(distances[0], indices[0]), start=1):

    row = historical_df.iloc[idx]

    # Adaptive similarity score (0–100%)
    if max_distance != min_distance:
        similarity = 100 * (1 - ((distance - min_distance) / (max_distance - min_distance)))
    else:
        similarity = 100.0

    similar_days.append({
        "date": row["candle_time"].date(),
        "close": row["close"],
        "distance": distance,
        "similarity": round(similarity, 2),
        "return_5d": row["return_5d"],
        "return_10d": row["return_10d"]
    })

    print(
        f"{rank:2d}. "
        f"{row['candle_time'].date()}   "
        f"Similarity={similarity:6.2f}%   "
        f"Distance={distance:6.3f}"
    )

     
similar_df = pd.DataFrame(similar_days)

similar_df = similar_df.sort_values(
    "similarity",
    ascending=False
).reset_index(drop=True)

print("\nPackage 2 Completed Successfully.")

# -------------------------------------------------------
# Package 3 - Historical Probability Engine
# -------------------------------------------------------

print("\n" + "=" * 70)
print("PACKAGE 3 - HISTORICAL PROBABILITY")
print("=" * 70)

# Remove rows where future returns are unavailable
stats_df = similar_df.dropna(subset=["return_5d", "return_10d"]).copy()

if len(stats_df) == 0:
    print("\nNo historical statistics available.")
else:

    win_rate = (stats_df["return_5d"] > 0).mean() * 100
    loss_rate = 100 - win_rate

    avg5 = stats_df["return_5d"].mean()
    avg10 = stats_df["return_10d"].mean()

    median5 = stats_df["return_5d"].median()
    median10 = stats_df["return_10d"].median()

    best5 = stats_df["return_5d"].max()
    worst5 = stats_df["return_5d"].min()

    positive = stats_df.loc[stats_df["return_5d"] > 0, "return_5d"]
    negative = stats_df.loc[stats_df["return_5d"] < 0, "return_5d"]

    if len(positive) > 0 and len(negative) > 0:
        risk_reward = positive.mean() / abs(negative.mean())
    else:
        risk_reward = 0

    print(f"\nHistorical Samples : {len(stats_df)}")

    print(f"Bullish Win Rate   : {win_rate:.2f}%")
    print(f"Bearish Rate       : {loss_rate:.2f}%")

    print(f"\nAverage 5-Day Return  : {avg5:.2f}%")
    print(f"Average 10-Day Return : {avg10:.2f}%")

    print(f"\nMedian 5-Day Return   : {median5:.2f}%")
    print(f"Median 10-Day Return  : {median10:.2f}%")

    print(f"\nBest 5-Day Return     : {best5:.2f}%")
    print(f"Worst 5-Day Return    : {worst5:.2f}%")

    print(f"\nRisk / Reward Ratio   : {risk_reward:.2f}")

print("\nPackage 3 Completed Successfully.")
# -------------------------------------------------------
# Decision Logic
# -------------------------------------------------------

if win_rate >= 70 and avg5 > 0:
    recommendation = "STRONG BUY"

elif win_rate >= 55 and avg5 > 0:
    recommendation = "BUY"

elif win_rate <= 30 and avg5 < 0:
    recommendation = "SELL"

elif win_rate <= 45 and avg5 < 0:
    recommendation = "WEAK SELL"

else:
    recommendation = "HOLD"

# -------------------------------------------------------
# Confidence Score
# -------------------------------------------------------

confidence = 50

if win_rate >= 70:
    confidence += 20

elif win_rate <= 30:
    confidence += 20

if abs(avg5) >= 2:
    confidence += 10

if abs(avg10) >= 2:
    confidence += 10

confidence = min(confidence, 100)

# -------------------------------------------------------
# Confidence Level
# -------------------------------------------------------

if confidence >= 85:
    confidence_level = "VERY HIGH"

elif confidence >= 70:
    confidence_level = "HIGH"

elif confidence >= 55:
    confidence_level = "MEDIUM"

else:
    confidence_level = "LOW"

# -------------------------------------------------------
# Report
# -------------------------------------------------------


# -------------------------------------------------------
# Package 5 - Confidence Engine
# -------------------------------------------------------

print("\n" + "=" * 70)
print("PACKAGE 5 - AI CONFIDENCE ENGINE")
print("=" * 70)

confidence = 0

confidence += similar_df["similarity"].mean() * 0.40
confidence += win_rate * 0.40
confidence += max(avg10, 0) * 5

confidence = min(100, round(confidence, 2))

if confidence >= 85:
    signal = "Very Strong"

elif confidence >= 70:
    signal = "Strong"

elif confidence >= 55:
    signal = "Moderate"

elif confidence >= 40:
    signal = "Weak"

else:
    signal = "Very Weak"

print(f"\nAI Confidence : {confidence}%")
print(f"Signal Strength : {signal}")
if win_rate >= 70:
    recommendation = "BUY"

elif win_rate <= 30:
    recommendation = "SELL"

else:
    recommendation = "WAIT"

print(f"\nAI Recommendation : {recommendation}")

summary = {

    "analysis_date": historical_df.iloc[-1]["candle_time"].date(),

    "close": historical_df.iloc[-1]["close"],

    "trend": "Strong Uptrend",

    "confidence": confidence,

    "bullish_rate": win_rate,

    "bearish_rate": 100 - win_rate,

    "avg5": avg5,

    "avg10": avg10,

    "recommendation": recommendation

}
print("\n" + "=" * 70)
print("PACKAGE 6 - AI DECISION ENGINE")
print("=" * 70)
print(f"\nRecommendation : {recommendation}")
print(f"Confidence     : {confidence}/100")
print(f"Confidence Lv. : {confidence_level}")

print("\nReasons")

if win_rate >= 70:
    print("✓ Strong bullish historical probability")

elif win_rate <= 30:
    print("✓ Strong bearish historical probability")

if avg5 > 0:
    print("✓ Positive average 5-Day return")
else:
    print("✓ Negative average 5-Day return")

if avg10 > 0:
    print("✓ Positive average 10-Day return")
else:
    print("✓ Negative average 10-Day return")

print("\nPackage 6 Completed Successfully.")
