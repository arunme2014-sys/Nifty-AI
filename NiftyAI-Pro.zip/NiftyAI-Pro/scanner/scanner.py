import pandas as pd
from sqlalchemy import create_engine
from config.settings import DATABASE_URL

engine = create_engine(DATABASE_URL)

query = """
SELECT
    c.candle_time,
    c.close,
    i.ema20,
    i.ema50,
    i.ema200,
    i.rsi14,
    i.macd,
    i.macd_signal,
    i.atr14
FROM candle c
JOIN indicator i
ON c.id=i.candle_id
ORDER BY c.candle_time DESC
LIMIT 1;
"""

df = pd.read_sql(query, engine)

row = df.iloc[0]

print("=" * 60)
print("            NIFTY AI MARKET SCANNER")
print("=" * 60)

print(f"Date        : {row.candle_time.date()}")
print(f"Close       : {row.close:.2f}")

print()

# Trend

print("TREND")

print("----------------------------------------")

print("Above EMA20 :", row.close > row.ema20)
print("Above EMA50 :", row.close > row.ema50)
print("Above EMA200:", row.close > row.ema200)

print()

# Momentum

print("MOMENTUM")

print("----------------------------------------")

print(f"RSI14       : {row.rsi14:.2f}")

if row.macd > row.macd_signal:
    print("MACD        : Bullish")
else:
    print("MACD        : Bearish")

print()

# Volatility

print("VOLATILITY")

print("----------------------------------------")

print(f"ATR14       : {row.atr14:.2f}")

print()

score = 0

if row.close > row.ema20:
    score += 20

if row.close > row.ema50:
    score += 20

if row.close > row.ema200:
    score += 20

if row.rsi14 > 50:
    score += 20

if row.macd > row.macd_signal:
    score += 20

print("=" * 60)
print("MARKET SCORE :", score, "/100")
print("=" * 60)