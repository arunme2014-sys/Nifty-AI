"""
Sprint 12
Package 5

Production Validation Engine
"""

from dataclasses import dataclass


@dataclass
class ValidationResult:

    database: bool
    support_valid: bool
    resistance_valid: bool
    risk_valid: bool
    reward_valid: bool
    rr_valid: bool
    trade_grade_valid: bool
    overall_status: str


class ProductionValidator:

    def validate(

        self,

        current_price,

        support,

        resistance,

        risk,

        reward,

        rr,

        trade_grade,

        database_ok=True,

    ):

        support_valid = support < current_price

        resistance_valid = resistance > current_price

        risk_valid = risk > 0

        reward_valid = reward > 0

        rr_valid = rr >= 1.0

        trade_grade_valid = trade_grade in ["A", "B", "C"]

        passed = sum(
            [
                database_ok,
                support_valid,
                resistance_valid,
                risk_valid,
                reward_valid,
                rr_valid,
                trade_grade_valid,
            ]
        )

        if passed == 7:
            status = "PASS"

        elif passed >= 5:
            status = "WARNING"

        else:
            status = "FAIL"

        return ValidationResult(

            database=database_ok,

            support_valid=support_valid,

            resistance_valid=resistance_valid,

            risk_valid=risk_valid,

            reward_valid=reward_valid,

            rr_valid=rr_valid,

            trade_grade_valid=trade_grade_valid,

            overall_status=status,

        )

    # -----------------------------------------------------

    def print_report(self, result):

        print()

        print("=" * 70)

        print("PRODUCTION VALIDATION")

        print("=" * 70)

        print()

        print(f"Database              : {'PASS' if result.database else 'FAIL'}")

        print(f"Support Validation    : {'PASS' if result.support_valid else 'FAIL'}")

        print(f"Resistance Validation : {'PASS' if result.resistance_valid else 'FAIL'}")

        print(f"Risk Validation       : {'PASS' if result.risk_valid else 'FAIL'}")

        print(f"Reward Validation     : {'PASS' if result.reward_valid else 'FAIL'}")

        print(f"Risk Reward           : {'PASS' if result.rr_valid else 'FAIL'}")

        print(f"Trade Grade           : {'PASS' if result.trade_grade_valid else 'FAIL'}")

        print()

        print("-" * 70)

        print()

        print("Overall Status :", result.overall_status)

        print()

        print("=" * 70)