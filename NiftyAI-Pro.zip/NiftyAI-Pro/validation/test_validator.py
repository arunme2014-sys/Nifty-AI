from validation.production_validator import ProductionValidator

validator = ProductionValidator()

result = validator.validate(

    current_price=23865.75,

    support=23847.85,

    resistance=23869.60,

    risk=143.22,

    reward=-2.12,

    rr=0.18,

    trade_grade="D",

)

validator.print_report(result)